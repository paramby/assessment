﻿In Single Entry System, We Start with our existing cash balance for a 
given period, then add the income we receive and subtract our expenses. 
After we factor in all these transactions, at the end of the given period, 
we calculate the cash balance we are left with.

Entity:- TransactionEntry Class
==================================
TransactionDate - The date on which the transaction takes place
Description - A brief note on the item
Notes - A brief note on the transaction
TransactionValue - The value can be either incoming (debit) or outgoing (credit)
AccountBalance - Running total of how much cash you have in hand

Value Object:- TransactionValue Class
======================================
Type - Type can be either incoming (debit) or outgoing (credit)
Amount - The amount debited/credited

Shortcomings of Single Entry System
====================================
1) Recording method: 
Single-entry bookkeeping gives a one-sided picture of transactions recorded 
in the cash register. In double entry, changes due to one transaction are 
reflected in at least two accounts. The double-entry system is preferred by 
investors, banks and buyers because it gives them a more complete financial 
picture of an organization.

2) Error detection: 
In double entry, debits and credits must always be the same. If that is not 
the case, then there is an error. This makes it easy to spot errors and 
ensure that they are not carried forward to other journals and financial 
statements. In single entry, there is no method for error correction or 
detection.

3) Company size: 
The single-entry system is only appropriate for small enterprises, whereas 
the double-entry system can be used by all sizes of businesses, including 
large ones.

4) Preparation of financial statements: 
The information recorded in a single-entry system isn’t adequate for financial
reporting or preparing profit and loss statements. Bigger organizations rely 
on these reports to track their performance, so they need the extra 
information captured by double-entry accounting.