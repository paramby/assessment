﻿using ASPNETRateLimiterDemo.UsingCustomMiddleware.Middlewares;
using Microsoft.AspNetCore.Builder;

namespace ASPNETRateLimiterDemo.UsingCustomMiddleware.Extensions
{

    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseRateLimiting(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RateLimitingMiddleware>();
        }
    }
}

