﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModelling.Model
{
    // DDD Entity
    public class TransactionEntry
    {
        public DateTime TransactionDate { get; set; }
        public string Description { get; set; }
        public string Notes { get; set; }
        public TransactionValue TransactionValue { get; set; }
        public decimal AccountBalance { get; set; }
    }

    // Value Object
    public class TransactionValue
    {
        public string Type { get; set; }
        public string Amount { get; set; }
    }
}
