﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisibilityConsoleApp
{
    public static class DivisibilityTest
    {
        public static string CheckDivisibility(int i)
        {
            // i is divisible by 3
            if (i % 3 == 0 && i % 5 != 0)
            {
                return "Fizz";
            }
            // i is divisible by 5
            else if (i % 3 != 0 && i % 5 == 0)
            {
                return "Buzz";
            }
            // i is divisible by both 3 and 5
            else if (i % 3 == 0 && i % 5 == 0)
            {
                return "FizzBuzz";
            }
            // i is not divisible by 3 or 5
            else
            {
                return Convert.ToString(i);
            }
        }
    }
}
