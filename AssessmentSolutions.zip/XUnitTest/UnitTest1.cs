using System;
using DivisibilityConsoleApp;
using Xunit;

namespace XUnitTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            var i = 87808;
            var result = DivisibilityTest.CheckDivisibility(i);
            if (result == "FizzBuzz")
                Assert.Equal("FizzBuzz", result);
            if (result == "Fizz")
                Assert.Equal("Fizz", result);
            if (result == "Buzz")
                Assert.Equal("Buzz", result);
            if (result == Convert.ToString(i))
                Assert.Equal(Convert.ToString(i), result);
        }
    }
}
